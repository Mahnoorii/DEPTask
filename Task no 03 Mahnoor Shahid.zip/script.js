// script.js

// Function to add product to cart
function addToCart(productId) {
    // Logic to add product to cart
    console.log(`Product ${productId} added to cart`);
}

// Function to update cart
function updateCart() {
    // Logic to update cart
    console.log("Cart updated");
}
